package activity.android.com.microsoftdemoapplication.service;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.os.AsyncTask;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import activity.android.com.microsoftdemoapplication.adapter.ImageListAdapter;
import activity.android.com.microsoftdemoapplication.model.ImageModel;
import activity.android.com.microsoftdemoapplication.utility.AppUtils;

/**
 * Created by koroy on 6/17/2016.
 */
public class SearchJobTask extends AsyncTask<String, String, String> {

    private ProgressDialog pDialog;
    private Context context;
    private String url;

    private RecyclerView recyclerView;
    private CoordinatorLayout coordinatorLayout;


    public SearchJobTask(Context mContext,String url,RecyclerView recyler,CoordinatorLayout coordinatorLayout){
        context=mContext;
        this.url=url;
        this.recyclerView=recyler;
        this.coordinatorLayout=coordinatorLayout;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pDialog = new ProgressDialog(context);
        pDialog.setMessage("Getting Searched images ...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();

    }

    @Override
    protected String doInBackground(String... args) {
        // Getting JSON from URL
        String json = getResponseFromUrl(url);
        return json;
    }
    @Override
    protected void onPostExecute(String json) {
        pDialog.dismiss();
        if(json!=null ) {
                ArrayList<ImageModel> imageModelList=parseResponse(json);
                //Setting adapter with the searched value
                ImageListAdapter imageListAdapter = new ImageListAdapter(context, imageModelList);
                imageListAdapter.notifyDataSetChanged();
                recyclerView.setAdapter(imageListAdapter);
        }else{
            //Response is null
            Toast.makeText(context,"Something went wrong.Please try again",Toast.LENGTH_SHORT).show();
        }

    }

    private void showSnackBar(String msg){
        Snackbar snackbar = Snackbar
                .make(coordinatorLayout, msg, Snackbar.LENGTH_LONG);

        snackbar.show();
    }


    /**
     * Parsing the fetched JSON Response
     * @param json
     * @return
     */
    private ArrayList<ImageModel> parseResponse(String json){
        ImageModel imageModel;
        ArrayList<ImageModel> imageModels = new ArrayList<ImageModel>();
        try {
        JsonFactory factory = new JsonFactory();
        ObjectMapper mapper = new ObjectMapper(factory);
        JsonNode rootNode = mapper.readTree(json);
        JsonNode queryNode = rootNode.findValue(AppUtils.QUERY_TAG);
        if(queryNode!=null) {
            JsonNode pages = queryNode.findValue(AppUtils.PAGES_TAG);
            if(pages!=null) {
                Iterator<Map.Entry<String, JsonNode>> fieldsIterator = pages.fields();
                while (fieldsIterator.hasNext()) {
                    //Iterate through the response
                    Map.Entry<String, JsonNode> field = fieldsIterator.next();
                    JsonNode node = field.getValue();
                    String title = node.findValue(AppUtils.TITLE_TAG).toString().replaceAll("\"", "");
                    JsonNode thumbnail = node.findValue(AppUtils.THUMBNAIL_TAG);
                    if (thumbnail != null) {
                        //Check if image exists.If not dont add in the list
                        String imgUrl = thumbnail.findValue(AppUtils.SOURCE_TAG).toString().replaceAll("\"", "");
                        imageModel = new ImageModel();
                        imageModel.setImgName(title);
                        imageModel.setImgUrl(imgUrl);
                        imageModels.add(imageModel);
                    }

                }

            }else{
                showSnackBar("No Images Found");
            }
        }else{
            //Toast.makeText(context,"No Images Found",Toast.LENGTH_SHORT).show();
            showSnackBar("No Images Found");
        }
        } catch (IOException e) {
            Toast.makeText(context,"Something went wrong.Please try again",Toast.LENGTH_SHORT).show();
            //e.printStackTrace();
        }
        return imageModels;
    }

    /**
     * Backend connection with the webservice API
     * @param src
     * @return
     */
    public String getResponseFromUrl(String src) {
        String json=null;
        // Making HTTP request
        try {
            // Making Url connection
            java.net.URL url = new java.net.URL(src);
            HttpURLConnection connection = (HttpURLConnection) url
                    .openConnection();
            connection.setDoInput(true);
            connection.connect();
            final int statusCode = connection.getResponseCode();
            //Checking status before proceed
            if (statusCode != HttpURLConnection.HTTP_OK) {
                Toast.makeText(context,"Server connection exception",Toast.LENGTH_SHORT).show();
                Log.w("ImageDownloader", "Error " + statusCode + " while retrieving data from " + url);
                return null;
            }

            InputStream inputStream = null;
            try {
                //Getting api data into string using string builder
                inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        inputStream, "iso-8859-1"), 8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "n");
                }
                inputStream.close();
                json = sb.toString();
            } catch (Exception e) {
                Toast.makeText(context,"Error converting result ",Toast.LENGTH_SHORT).show();
                Log.e("Buffer Error", "Error converting result " + e.toString());
            }


        }catch (Exception e){
            Toast.makeText(context,"Oops!Some unexpected exception.Please try again ",Toast.LENGTH_SHORT).show();
            Log.d("Exception",""+e.toString());
        }

        // return JSON String
        return json;

    }


}
