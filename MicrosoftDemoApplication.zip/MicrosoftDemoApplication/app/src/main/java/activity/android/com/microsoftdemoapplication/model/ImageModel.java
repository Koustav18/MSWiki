package activity.android.com.microsoftdemoapplication.model;

/**
 * Created by koroy on 6/17/2016.
 */
public class ImageModel {
    private String imgUrl;
    private String imgName;

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getImgName() {
        return imgName;
    }

    public void setImgName(String imgName) {
        this.imgName = imgName;
    }
}
