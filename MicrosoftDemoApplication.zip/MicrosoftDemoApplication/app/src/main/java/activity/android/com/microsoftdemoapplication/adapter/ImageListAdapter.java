package activity.android.com.microsoftdemoapplication.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import java.util.ArrayList;

import activity.android.com.microsoftdemoapplication.R;
import activity.android.com.microsoftdemoapplication.model.ImageModel;

/**
 * Created by koroy on 6/17/2016.
 */
public class ImageListAdapter extends RecyclerView.Adapter<ImageListAdapter.MyViewHolder> {
    ArrayList<ImageModel> data;
    private LayoutInflater inflater;
    private Context context;
    // Allows to remember the last item shown on screen
    private int lastPosition = -1;



    public ImageListAdapter(Context context, ArrayList<ImageModel> data) {
        this.context = context;
        inflater = LayoutInflater.from(context);
        this.data = data;

    }

    public void delete(int position) {
        data.remove(position);
        notifyItemRemoved(position);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.image_row, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        view.setTag(holder);
        return holder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final ImageModel imageModel = data.get(position);
        Typeface font = Typeface.createFromAsset(context.getAssets(), "Chantelli_Antiqua.ttf");
        holder.imgTitle.setText(imageModel.getImgName());
        holder.imgTitle.setTypeface(font);
        //Load images with respective url using Picasso library
        Picasso.with(context).load(imageModel.getImgUrl()).resize(50, 50).into(holder.img);
        // Applying animation when the view is bound
        setAnimation(holder.container, position);


    }

    /**
     * Method to apply the animation
     */
    private void setAnimation(View viewToAnimate, int position)
    {
        // If the bound view wasn't previously displayed on screen, it's animated
        if (position > lastPosition)
        {
            Animation animation = AnimationUtils.loadAnimation(context, android.R.anim.slide_in_left);
            viewToAnimate.startAnimation(animation);
            lastPosition = position;
        }
    }




    @Override
    public int getItemCount() {
        if(data==null)
            return 0;
        return data.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView imgTitle;
        ImageView img;
        CardView container;


        public MyViewHolder(View itemView) {
            super(itemView);
            imgTitle=(TextView)itemView.findViewById(R.id.image_title);
            img=(ImageView)itemView.findViewById(R.id.image_logo);
            container=(CardView)itemView.findViewById(R.id.card_view);
        }
    }
}
