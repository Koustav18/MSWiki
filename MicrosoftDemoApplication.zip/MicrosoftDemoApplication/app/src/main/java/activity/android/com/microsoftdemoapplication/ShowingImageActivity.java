package activity.android.com.microsoftdemoapplication;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import activity.android.com.microsoftdemoapplication.adapter.ImageListAdapter;
import activity.android.com.microsoftdemoapplication.model.ImageModel;
import activity.android.com.microsoftdemoapplication.service.SearchJobTask;
import activity.android.com.microsoftdemoapplication.utility.AppUtils;
import activity.android.com.microsoftdemoapplication.utility.ClearableEditText;
import activity.android.com.microsoftdemoapplication.utility.ConnectionDetector;

/**
 *Main Activity to start with
 */
public class ShowingImageActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private RecyclerView imageList;
    private ImageListAdapter adapter;
    private ClearableEditText search;
    private ImageView searchBtn;
    private TextView heading;
    private CoordinatorLayout coordinator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showing_image);

        initView();

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchText=search.getText().toString();
                hideSoftKeyboard(ShowingImageActivity.this,v);
                searchText(searchText);
            }
        });


    }

    private void initView(){
        coordinator=(CoordinatorLayout)findViewById(R.id.coordinator);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        Typeface font = Typeface.createFromAsset(getAssets(), "Chantelli_Antiqua.ttf");
        heading=(TextView)findViewById(R.id.header);
        heading.setTypeface(font);
        imageList = (RecyclerView) findViewById(R.id.seacr_result);

        adapter = new ImageListAdapter(this, null);
        imageList.setAdapter(adapter);
        imageList.setLayoutManager(new LinearLayoutManager(this));

        searchBtn=(ImageView)findViewById(R.id.search);
        search=(ClearableEditText)findViewById(R.id.input_search);
        search.setTypeface(font);

    }
    private void hideSoftKeyboard (Activity activity, View view)
    {
        InputMethodManager imm = (InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
    }

   private void searchText(String searchText){
       if(!TextUtils.isEmpty(searchText)){
           //Detect Internet connectivity before search
           ConnectionDetector cd = new ConnectionDetector(getApplicationContext());
           if( cd.isConnectingToInternet()) {
               //Internet available call search asynctask
               String url = AppUtils.MAIN_URL + searchText;
               SearchJobTask searchJobTask = new SearchJobTask(ShowingImageActivity.this, url, imageList,coordinator);
               searchJobTask.execute();
           }else{
               //Internet not available show Snack alert
               Snackbar snackbar = Snackbar
                       .make(coordinator, "No internet connection!", Snackbar.LENGTH_LONG)
                       .setAction("RETRY", new View.OnClickListener() {
                           @Override
                           public void onClick(View view) {

                           }
                       });

               // Changing message text color
               snackbar.setActionTextColor(Color.RED);

               // Changing action button text color
               View sbView = snackbar.getView();
               TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
               textView.setTextColor(Color.YELLOW);
               snackbar.show();
           }
       }else{
           //No Search value found dont proceed
           Snackbar snackbar = Snackbar
                   .make(coordinator, "Enter Search Value", Snackbar.LENGTH_LONG);

           snackbar.show();
       }
   }




}
