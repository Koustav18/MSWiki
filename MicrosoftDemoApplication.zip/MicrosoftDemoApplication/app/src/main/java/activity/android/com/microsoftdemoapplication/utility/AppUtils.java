package activity.android.com.microsoftdemoapplication.utility;

/**
 * Created by koroy on 6/17/2016.
 */
public class AppUtils {
    public static final String MAIN_URL="https://en.wikipedia.org/w/api.php?action=query&prop=pageimages&format=json&piprop=thumbnail&pithumbsize=50&pilimit=50&generator=prefixsearch&gpssearch=";
    public static final String QUERY_TAG="query";
    public static final String PAGES_TAG="pages";
    public static final String TITLE_TAG="title";
    public static final String THUMBNAIL_TAG="thumbnail";
    public static final String SOURCE_TAG="source";
}
